local exampleGUI = {}
function exampleGUI.unload()
	
end
function exampleGUI.kaboomb()
	print("KABOOM")
end
function exampleGUI.init()
	
	--[[exampleGUI.GUI = Libs["GUI"]

	exampleGUI.GUI.addButton("a",exampleGUI.kaboomb,0,0.2,0.05,0.05)
	exampleGUI.GUI.addButton("b",exampleGUI.kaboomb,0,0.2,0.05,0.05)
	exampleGUI.GUI.addButton("c",exampleGUI.kaboomb,0,0.2,0.05,0.05)
	exampleGUI.GUI.addButton("d",exampleGUI.kaboomb,0,0.2,0.05,0.05)
	--]]
	
end
function exampleGUI.tick()
	
--exampleGUI.GUI.tick()
end

return exampleGUI