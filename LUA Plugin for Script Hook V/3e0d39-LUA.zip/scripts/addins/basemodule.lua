local basemodule = {}

function basemodule.unload()
end
function basemodule.init()

end
function basemodule.tick()
	
end


return basemodule